"""Declarative candidate packet; runtime evaluates strategy.descriptor.json."""
STRATEGY_CODE = "GEX_NVDA_AUGUST_2026_BEST"
VERSION = "1.0.1-research"
SIGNAL_CODE = "NVDA_AUGUST_2026_BEST_SIGNAL"
DIRECTION = "LONG"
HOLDING_PERIOD = "D5"
TRIGGER = 'BCShareRank60 >= 0.80 AND ConcentrationHHIRank60 >= 0.80'
REQUIRED_INPUTS = ['BCShareRank60', 'ConcentrationHHIRank60']
DEPLOYMENT_TARGET = "RESEARCH_ONLY"
NOTIFICATIONS_ENABLED = False
BROKER_EXECUTION = "HARD_DISABLED"
