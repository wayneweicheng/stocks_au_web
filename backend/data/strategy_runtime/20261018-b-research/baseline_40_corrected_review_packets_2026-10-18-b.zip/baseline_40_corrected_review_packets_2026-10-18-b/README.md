**BLOCKED: research feature values are not equivalent to the runtime evaluator for 459/1298 ledger rows. Do not use this archive for baseline PF or provisioning. Use the separately audited runtime-aligned review archive instead.**

# Frozen 40 corrected baseline — REVIEW ONLY

Preserves the existing 20261018-a 40 ticker/horizon/direction/trigger selections. Recomputes **August only** using independently audited subject-symbol 30M labels. Old selection and September/October research were inspected; no OOS claim. Gross packet performance and separate 25-bp net sensitivity are **overlapping per-signal statistics, not portfolio results**. Original archive untouched. Descriptors are RESEARCH_DRAFT with deployment and notification disabled; broker execution HARD_DISABLED. Source missing required inputs fail closed. See `validation-issues.json`, `master-manifest.json`, `reconciled-trades.csv` and `strategy-summary.csv`. Never provision from this review archive.
