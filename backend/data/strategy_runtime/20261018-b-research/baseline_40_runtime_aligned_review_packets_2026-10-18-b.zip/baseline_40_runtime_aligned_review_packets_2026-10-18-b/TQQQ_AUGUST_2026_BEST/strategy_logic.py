"""Declarative candidate packet; runtime evaluates strategy.descriptor.json."""
STRATEGY_CODE = "GEX_TQQQ_AUGUST_2026_BEST"
VERSION = "1.0.2-research"
SIGNAL_CODE = "TQQQ_AUGUST_2026_BEST_SIGNAL"
DIRECTION = "SHORT"
HOLDING_PERIOD = "D5"
TRIGGER = 'PriceDistSMA50Pct <= -2.0 AND PutBuyShareChgAbsRank60 >= 0.80'
REQUIRED_INPUTS = ['PriceDistSMA50Pct', 'PutBuyShareChgAbsRank60']
DEPLOYMENT_TARGET = "RESEARCH_ONLY"
NOTIFICATIONS_ENABLED = False
BROKER_EXECUTION = "HARD_DISABLED"
